this is a small project of color detector software using tkinter in python


first install the following:

pip install pillow
pip install colorthief