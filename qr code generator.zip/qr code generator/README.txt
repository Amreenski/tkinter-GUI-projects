this is a small project of QR code generator using python

install 4 modules

pip install PyQRCode
pip install pypng
pip install pyzbar
pip install Pillow

https://pypi.org/project/PyQRCode/

https://pypi.org/project/pypng/

https://pypi.org/project/pyzbar/

https://pypi.org/project/Pillow/
