#importing libraries
import pyqrcode

text= input('site link\n')
#text="https://www.google.com/webhp?hl=en&sa=X&ved=0ahUKEwi6qJ6dier8AhWL1jgGHaERDF8QPAgI"
qr=pyqrcode.create(text)

#storing the file in the same folder with name abc.png
qr.png("abc.png",scale=6)
