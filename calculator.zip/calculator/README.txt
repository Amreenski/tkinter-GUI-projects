this is a small project of simple calculator using tkinter in python
