#importing libraries

import tkinter
from tkinter import *

#initialising tkinter window
root=Tk()
root.title("Simple Calculator")
root.geometry('325x450')
root.resizable(False,False)
root.configure(bg="#17161b")

equation=""

#display

def show(val):
    global equation
    equation+=val
    label_result.config(text=equation)

#all clear command
def clear():
    global equation
    equation=""
    label_result.config(text=equation)

#delete one command
def delete():
    global equation
    length=len(equation)
    equation=equation[:-1]
    label_result.config(text=equation)

#calculation of the equation:what to be done when = is clicked
def calculate():
    global equation
    result=""
    if equation!="":
        try:
            result=eval(equation)
        except:
            result="error"
            equation=""
    label_result.config(text=result)

#initializing display properties
label_result= Label(root,width=325,height=5,text="",font=("arial",20))
label_result.pack()

#buttons on calculator

Button(root,text="CE",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="orange",command=lambda: clear()).place(x=10,y=175)
Button(root,text="C",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:delete()).place(x=90,y=175)
Button(root,text="%",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("%")).place(x=170,y=175)
Button(root,text="/",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("/")).place(x=250,y=175)

Button(root,text="7",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("7")).place(x=10,y=230)
Button(root,text="8",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("8")).place(x=90,y=230)
Button(root,text="9",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("9")).place(x=170,y=230)
Button(root,text="*",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("*")).place(x=250,y=230)

Button(root,text="4",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("4")).place(x=10,y=285)
Button(root,text="5",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("5")).place(x=90,y=285)
Button(root,text="6",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("6")).place(x=170,y=285)
Button(root,text="-",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("-")).place(x=250,y=285)

Button(root,text="1",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("1")).place(x=10,y=340)
Button(root,text="2",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("2")).place(x=90,y=340)
Button(root,text="3",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("3")).place(x=170,y=340)
Button(root,text="+",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("+")).place(x=250,y=340)

Button(root,text=".",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show(".")).place(x=10,y=395)
Button(root,text="0",width=12,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="grey",command=lambda:show("0")).place(x=90,y=395)
Button(root,text="=",width=5,height=1,font=("arial",15,"bold"),bd=2,fg="#fff",bg="orange",command=lambda:calculate()).place(x=250,y=395)



root.mainloop()
